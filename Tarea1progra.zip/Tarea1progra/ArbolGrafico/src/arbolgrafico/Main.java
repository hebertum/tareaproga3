
package arbolgrafico;

/**
 *
 * Dell
 */
public class Main {

    
    public static void main(String[] args) {
   
        new Gui().setVisible(true);
    }
}
